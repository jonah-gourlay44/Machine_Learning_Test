from setuptools import setup

setup(
    name='Machine_Learning',
    url='https://github.com/jonah-gourlay44/Machine_Learning_Test',
    packages=['k-NN'],
    install_requires=['numpy'],
)