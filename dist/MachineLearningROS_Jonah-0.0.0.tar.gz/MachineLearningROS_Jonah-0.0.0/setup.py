from setuptools import setup

setup(
    name='MachineLearningROS_Jonah',
    url='https://github.com/jonah-gourlay44/Machine_Learning_Test',
    packages=['k-NN'],
    install_requires=['numpy'],
)